
var config = {
    'port': 5000,
    'frontend': 'http://localhost:3000/'
}
module.exports = config;