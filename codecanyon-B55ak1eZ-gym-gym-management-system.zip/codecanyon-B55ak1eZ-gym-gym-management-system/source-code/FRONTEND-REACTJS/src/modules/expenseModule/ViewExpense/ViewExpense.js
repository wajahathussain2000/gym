import React from 'react';
import PropTypes from 'prop-types';
import './ViewExpense.css';

const ViewExpense = () => (
  <div className="ViewExpense">
    ViewExpense Component
  </div>
);

ViewExpense.propTypes = {};

ViewExpense.defaultProps = {};

export default ViewExpense;
