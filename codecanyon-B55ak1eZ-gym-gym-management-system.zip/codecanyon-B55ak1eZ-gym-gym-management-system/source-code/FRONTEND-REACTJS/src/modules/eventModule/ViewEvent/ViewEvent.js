import React from 'react';
import PropTypes from 'prop-types';
import './ViewEvent.css';

const ViewEvent = () => (
  <div className="ViewEvent">
    ViewEvent Component
  </div>
);

ViewEvent.propTypes = {};

ViewEvent.defaultProps = {};

export default ViewEvent;
