import React from 'react';
import PropTypes from 'prop-types';
import './ViewExercice.css';

const ViewExercice = () => (
  <div className="ViewExercice">
    ViewExercice Component
  </div>
);

ViewExercice.propTypes = {};

ViewExercice.defaultProps = {};

export default ViewExercice;
