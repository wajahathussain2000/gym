import React from 'react';
import PropTypes from 'prop-types';
import './ViewPresence.css';

const ViewPresence = () => (
  <div className="ViewPresence">
    ViewPresence Component
  </div>
);

ViewPresence.propTypes = {};

ViewPresence.defaultProps = {};

export default ViewPresence;
