import React from 'react';
import PropTypes from 'prop-types';
import './EditPresence.css';

const EditPresence = () => (
  <div className="EditPresence">
    EditPresence Component
  </div>
);

EditPresence.propTypes = {};

EditPresence.defaultProps = {};

export default EditPresence;
