import React from 'react';
import PropTypes from 'prop-types';
import './AddPresence.css';

const AddPresence = () => (
  <div className="AddPresence">
    AddPresence Component
  </div>
);

AddPresence.propTypes = {};

AddPresence.defaultProps = {};

export default AddPresence;
