import React from 'react';
import PropTypes from 'prop-types';
import './History.css';

const History = () => (
  <div className="content">
          <div className="row">
            <div className="col-md-12">
              <div className="card">
                <div className="card-header">
                  <h4 className="card-title"> Historique</h4>
                </div>
                <div className="card-body">
                  <div className="table-responsive">
                    <table className="table">
                      
                    </table>
                  </div>
                </div>
              </div>
            </div>
          
          </div>
        </div>
);

History.propTypes = {};

History.defaultProps = {};

export default History;
