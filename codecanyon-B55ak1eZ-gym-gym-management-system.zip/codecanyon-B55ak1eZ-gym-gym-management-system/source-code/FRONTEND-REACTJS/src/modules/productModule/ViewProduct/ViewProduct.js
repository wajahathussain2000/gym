import React from 'react';
import PropTypes from 'prop-types';
import './ViewProduct.css';

const ViewProduct = () => (
  <div className="ViewProduct">
    ViewProduct Component
  </div>
);

ViewProduct.propTypes = {};

ViewProduct.defaultProps = {};

export default ViewProduct;
