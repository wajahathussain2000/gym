import React from 'react';
import PropTypes from 'prop-types';
import './ViewRevenue.css';

const ViewRevenue = () => (
  <div className="ViewRevenue">
    ViewRevenue Component
  </div>
);

ViewRevenue.propTypes = {};

ViewRevenue.defaultProps = {};

export default ViewRevenue;
