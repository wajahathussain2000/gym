export default class User {
    static USER_NAME = "Admin"
    static CONNECTED_USER = false
    static USER_DETAIL = {}
    static DELETE_MSG = "Are you sure you want to remove ?"
    static BACKOFFICE_URL = "http://localhost:5000"
}