
const eventValidation = {
    event_name: "Event Name is required",
    event_date: "Event date is required",
    place_id: "Place is required",
    starttime: "Start time is required",
    endtime: "End time is required",
}
export default eventValidation;