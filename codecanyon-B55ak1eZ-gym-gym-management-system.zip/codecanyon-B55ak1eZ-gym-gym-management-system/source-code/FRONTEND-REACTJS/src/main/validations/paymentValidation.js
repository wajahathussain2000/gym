
const paymentValidation = {
    type: 'Payment type is requied',
    member: 'Member is required',
    amount: 'Amount is required',
    validity: 'Validite doit etre definie',

}
export default paymentValidation;