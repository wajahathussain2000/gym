const activityValidation = {
    category: 'Category is required',
    title: 'Title is required',
    member: 'Member is required',
    type: 'Type is required'
}
export default activityValidation;