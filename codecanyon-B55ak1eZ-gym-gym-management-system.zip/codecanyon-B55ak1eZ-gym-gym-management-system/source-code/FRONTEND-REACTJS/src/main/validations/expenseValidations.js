
const expenseValidation = {
    date: 'Expense date is required',
    name: 'Expense name is required',
    amount: 'Amount is required',


}
export default expenseValidation;