
const presenceValidation = { post: 'le poste doit etre definie' }
export default presenceValidation;