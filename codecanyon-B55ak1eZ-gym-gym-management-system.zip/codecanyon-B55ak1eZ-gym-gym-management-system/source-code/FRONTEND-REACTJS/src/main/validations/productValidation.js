
const productValidation = {
    product_name: 'Product name is required',
    price: 'Price is required',
    quantity: 'Quantity is required',

}
export default productValidation;