
const groupeValidation = {
    groupe_name: 'Group name is required',

}
export default groupeValidation;