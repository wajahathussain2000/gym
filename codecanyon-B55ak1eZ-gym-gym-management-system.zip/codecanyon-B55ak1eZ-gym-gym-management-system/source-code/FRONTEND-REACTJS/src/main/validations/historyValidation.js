
const historyValidation = {
    full_name: "Nom  doit etre definie",
    email: "Email doit etre definie",
    password: "Mot de passe doit etre definie",
    calling_code: "Code doit etre definie",
    role_id: "Role doit etre definie",
}
export default historyValidation;